#include "Cinto.h"
#include <iostream>
using namespace std;

Cinto::Cinto(){
    count = 0;
}

Cinto::~Cinto(){
    cout << "Cinto destruído! " << endl;
}

bool Cinto::Empty(){
    return count == 0;
}

bool Cinto::Full(){
    return count == MaxCinto;
}

void Cinto::Insert(Item item, int p){
    if(Full()){
        cout << "Cinto cheio! Sem espaço para novo item! " << endl;
        abort();
    }
    if(p < 1 || p > count + 1){
        cout << "Posição inválida! " << endl;
        abort();
    }
    for(int i = count; i >= p; i--){
        Entry[i + 1] = Entry[i];
    }
    Entry[p] = item;
    count++;
}

void Cinto::Delete(Item &item, int p){
    if(Empty()){
        cout << "Não há itens para remover do cinto" << endl;
        abort();
    }
    if(p < 1 || p > count){
        cout << "Posição inválida! " << endl;
        abort();
    }
    item = Entry[p];
    for(int i = p; i < count; i++){
        Entry [i] = Entry [i + 1];
    }
    count--;
}

int Cinto::Size(){
    return count;
}

void Cinto::Clear(){
    count = 0;
}

void Cinto::Retrieve(Item &item, int p){
    if(p < 1 || p > count){
        cout << "Posição inválida" << endl;
        abort();
    }
    item = Entry[p];
}

void Cinto::Replace(Item item, int p){
    if(p < 1 || p > count){
        cout << "Posição inválida! " << endl;
        abort();
    }
    Entry[p] = item;
}

