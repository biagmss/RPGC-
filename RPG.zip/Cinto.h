#include <string>
using namespace std;

const int MaxCinto = 10;

struct Item {
    string nome, tipo;
    int peso, ataque, cura;
};

class Cinto{
public:
    Cinto();
    ~Cinto();
    bool Empty();
    bool Full();
    void Insert(Item item, int p);
    void Delete(Item &item, int p);
    int Size();
    void Clear();
    void Retrieve(Item &item, int p);
    void Replace(Item item, int p);
private:
    Item Entry[MaxCinto + 1];
    int count;
};
