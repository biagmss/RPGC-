#include <string>
#include <iostream>
using namespace std;

class Inimigo {
public:
    std::string nome;
    int vida;
    int ataque;

    Inimigo(std::string n = "", int v = 0, int a = 0) : nome(n), vida(v), ataque(a) {}

    void status() {
        cout << "Inimigo: " << nome << " | Vida: " << vida << " | Ataque: " << ataque << endl;
    }
};
