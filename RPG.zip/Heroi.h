#include "Cinto.h"
#include "Mochila.h"
#include <iostream>

class Heroi {
public:
    std::string nome;
    int vida;
    Cinto cinto;
    Stack mochila;

    Heroi(std::string n = "", int v = 100) : nome(n), vida(v) {}

    void status() {
        std::cout << "Herói: " << nome << " | Vida: " << vida << std::endl;
        std::cout << "Itens no cinto:" << std::endl;
        cinto.mostrarItens();
        std::cout << "Item no topo da mochila: " << mochila.verTopo() << std::endl;
    }

    void usarPocao() {
        int pocao;
        mochila.Pop(pocao);
        vida += pocao;
        std::cout << "Usou poção e recuperou " << pocao << " pontos de vida." << std::endl;
    }
};
