#include <string>

struct Item {
    std::string nome;
    int peso;
    std::string tipo; // Pode ser "arma" ou "poção"
    int valor; // Ataque ou cura

    Item(std::string n = "", int p = 0, std::string t = "", int v = 0) 
        : nome(n), peso(p), tipo(t), valor(v) {}
};
